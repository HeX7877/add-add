package com.example.fk_app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // craet e a variable

        val number1 = findViewById<EditText>(R.id.number1)
        val number2 = findViewById<EditText>(R.id.Number2)
        val add = findViewById<Button>(R.id.Button)
        val result = findViewById<TextView>(R.id.Result)

        add.setOnClickListener{
            val num1 = number1.text.toString().toInt()
            val num2 = number2.text.toString().toInt()

            var sum = num1 + num2
            result.text = sum.toString()
        }

        }
    }
